# Verific Imobil v2.1

Next.js property-listing analysis app using OpenAI `gpt-4o-mini`.

## Setup

1. `npm install`
2. Copy `.env.example` to `.env.local` and add your own OpenAI API key.
3. `npm run dev`
4. Open http://localhost:3000

## Deploy

Push the project files to GitHub, connect the repository to Vercel, and set `OPENAI_API_KEY` as a **Production** environment variable. Do not commit your actual API key.

## Important limitations

The report is indicative, not a technical inspection, legal verification or independent market valuation. Some listing sites block automated fetching; use manual description instead.

## Export note

This package is a **reconstructed v2.1 source export** based on the application design, not a byte-for-byte retrieval of the Vercel deployment. Vercel source-file retrieval was blocked by a permissions error.
